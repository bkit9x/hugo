---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: true
# summary: "Some summaries..."
# type: "post" or "status"
# author: Author
# featured_image: cover.jpg
# slug: aaa-bbb-ccc
# toc: true
# categories:
#   - CategoryA
#   - CategoryB
# tags:
#   - tagA
#   - tagB
---


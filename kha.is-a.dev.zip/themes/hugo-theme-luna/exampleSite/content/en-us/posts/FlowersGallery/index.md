---
title: Flower Gallery
date: 2022-04-15T02:49:13+02:00
slug: flower-gallery
featured_image: cover.jpg
summary: Some photos of flowers
layout: gallery
tags:
  - Flower
categories:
  - Gallery
---

{{< gallery >}}
![ROSE](1.jpg)
![ROSE](2.jpg)
![ROSE](3.jpg)

![ROSE](5.jpg)
![ROSE](4.jpg)
![ROSE](6.jpg)
{{< /gallery >}}

## Grid Gallery

> Spring, the sweet spring, is the year's pleasant king.

{{< gallery-grid >}}
![some text](1.jpg)
![some text](2.jpg)
![some text](3.jpg)
![some text](4.jpg)
![some text](5.jpg)
![some text](6.jpg)
{{< /gallery-grid >}}

---
author: Ice-Hazymoon
type: status
date: 2019-02-15T07:01:32+00:00
slug: luna-released
categories:
  - Luna
---

Hugo theme luna has been released, welcome to use it!
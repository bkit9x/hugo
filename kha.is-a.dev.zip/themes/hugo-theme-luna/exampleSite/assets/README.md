🎉🎉🎉 Hi everyone!! Hugo theme Luna has been released, welcome to use it, if you encounter problems, you can ask questions in [issues](https://github.com/Ice-Hazymoon/hugo-theme-luna/issues). Here are some notices that you can modify in [this file](https://github.com/Ice-Hazymoon/hugo-theme-luna/blob/master/exampleSite/assets/README.md) or delete it



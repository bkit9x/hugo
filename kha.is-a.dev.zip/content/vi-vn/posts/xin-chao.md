---
title: "Xin chào, đây là bài viết đầu tiên của tôi"
date: 2022-10-11T23:10:16+07:00
draft: false
summary: "Some summaries..."
featured_image: "https://codecungtui.github.io/images/tao-blog-don-gian-voi-hugo-va-github/cover.jpg"
categories:
  - CategoryA
  - CategoryB
tags:
  - tagA
  - tagB
toc: false
---


### Như bạn đã thấy, đây là bài viết đầu tiên của tôi.
Cảm ơn bạn đã ghé thăm blog của tôi.
Tôi rất vui khi được chia sẻ với bạn.
Bạn có thể liên hệ với tôi qua email: hoangkha@duck.com


Tôi sẽ cố gắng cập nhật blog của mình thường xuyên.
Đây là hình ảnh của tôi:

![Hình ảnh minh họa](https://codecungtui.github.io/images/tao-blog-don-gian-voi-hugo-va-github/cover.jpg)

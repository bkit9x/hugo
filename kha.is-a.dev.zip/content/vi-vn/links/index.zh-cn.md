---
title: "友情链接"
date: 2021-08-23T15:26:35+08:00
layout: "links"
---

#### 常用网站

{{< link url="https://github.com/" image="github.png" title="GitHub" desc="some desc text..." >}}
{{< link url="https://douban.com/" image="douban.png" title="Douban" desc="some desc text..." >}}
{{< link url="https://youtube.com/" image="youtube.png" title="YouTube" desc="some desc text..." >}}
{{< link url="https://sspai.com/" image="sspai.png" title="Sspai" desc="some desc text..." >}}
{{< link url="https://translate.google.com" image="translate.png" title="Translate" desc="some desc text..." >}}
{{< link url="https://tieba.com/" image="tieba.png" title="Tieba" desc="some desc text..." >}}
{{< link url="https://zhihu.com/" image="zhihu.png" title="Zhihu" desc="some desc text..." >}}
